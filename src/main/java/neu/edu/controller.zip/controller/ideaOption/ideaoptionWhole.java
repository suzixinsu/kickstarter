package neu.edu.controller.ideaOption;

public class ideaoptionWhole {
	public Integer optionId;
	public String optionDescription;
	public float optionPrice;
	public int optionBoughtAmount;
	public Integer optionMaxAmount;
	
	public ideaoptionWhole() {
		
	}

	public Integer getOptionId() {
		return optionId;
	}

	public void setOptionId(Integer optionId) {
		this.optionId = optionId;
	}

	public String getOptionDescription() {
		return optionDescription;
	}

	public void setOptionDescription(String optionDescription) {
		this.optionDescription = optionDescription;
	}

	public float getOptionPrice() {
		return optionPrice;
	}

	public void setOptionPrice(float optionPrice) {
		this.optionPrice = optionPrice;
	}

	public int getOptionBoughtAmount() {
		return optionBoughtAmount;
	}

	public void setOptionBoughtAmount(int optionBoughtAmount) {
		this.optionBoughtAmount = optionBoughtAmount;
	}

	public Integer getOptionMaxAmount() {
		return optionMaxAmount;
	}

	public void setOptionMaxAmount(Integer optionMaxAmount) {
		this.optionMaxAmount = optionMaxAmount;
	}

	
}
